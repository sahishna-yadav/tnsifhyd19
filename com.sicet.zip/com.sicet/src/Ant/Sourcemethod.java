package Ant;

public class Sourcemethod {
	void show() {
		System.out.println("hello what are you doing so");
	}
	void display() {
		System.out.println("hey where are you");
	}

}
class Method extends Sourcemethod{
	void show() {
		System.out.println("what are you doing so");
		
	}
	void display() {
		super.show();
		super.display();
	}
}
