package Ant;

public class Sourcmain {
	public static void main(String[] args) {
		Sorry s1=new Sorry();
		s1.display();
	}

}
