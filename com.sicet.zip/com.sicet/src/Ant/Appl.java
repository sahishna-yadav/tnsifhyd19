package Ant;

public class Appl {
	void display() {
		System.out.println("hey where are you");
	}
	void show() {
		System.out.println("hello! how are you");
	}
	public static void main(String[] args) {
		Appl a1=new Appl();
		a1.display();
		a1.show();
	}

}
