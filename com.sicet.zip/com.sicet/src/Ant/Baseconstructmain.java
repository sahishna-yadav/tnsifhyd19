package Ant;

public class Baseconstructmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Bend b1=new Bend();
       b1.show();
	}

}
