package Ant;

public class Sourceconstruct {
	Sourceconstruct(){
		System.out.println("hello how are you ");
	}

}
class Element extends Sourceconstruct{
	Element(){
		super();
		System.out.println("hey who is this");
		
			
		}
	}

