package Ant;
import Joke.*;

public class Abc extends Ef {

	public static void main(String[] args) {
		Abc c1=new Abc();
		System.out.println(c1.run());
		// TODO Auto-generated method stub

	}

}
