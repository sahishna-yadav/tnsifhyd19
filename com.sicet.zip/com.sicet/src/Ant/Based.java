package Ant;

abstract class Based {
 abstract void joke();

}
class Sour extends Based{
	void joke() {
		System.out.println("give a glass of water");
		
	}
	
}
