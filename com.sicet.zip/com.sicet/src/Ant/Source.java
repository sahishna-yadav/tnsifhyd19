package Ant;

public class Source {
	String colour="yellow";
	}
	class Sorry extends Source{
		String colour="blue";
		void display() {
			System.out.println(colour);
			System.out.println(super.colour);
		}
		
	}



