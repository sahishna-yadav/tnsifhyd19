package Ant;

public class Basedmain {

	public static void main(String[] args) {
		Sour s1=new Sour();
		    s1.joke();
		// TODO Auto-generated method stub

	}

}
