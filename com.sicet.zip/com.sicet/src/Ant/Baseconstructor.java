package Ant;

abstract class Baseconstructor {
	Baseconstructor(){
		System.out.println("hello lets go");
	}
	abstract void show();
		}
class Bend extends Baseconstructor{
	Bend(){
		System.out.println("where shall we go");
		}
	void show() {
		System.out.println("i am hungry lets have a dinner");
	}
}
