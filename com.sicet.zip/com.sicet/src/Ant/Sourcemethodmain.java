package Ant;

public class Sourcemethodmain {

	public static void main(String[] args) {
		Method m1=new Method();
		m1.show();
		m1.display();
	
		// TODO Auto-generated method stub

	}

}
