package Joke;

public class Ef {
	protected int run() {
		System.out.println("hey who is this");
		return 10;
		
	}

}


