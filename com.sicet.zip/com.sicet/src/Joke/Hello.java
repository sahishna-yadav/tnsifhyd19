package Joke;
import Ant.*;
public class Hello {
	public static void main(String args[]) {
		Appl a1=new Appl();
		a1.display();
		a1.show();
		
	}

}
