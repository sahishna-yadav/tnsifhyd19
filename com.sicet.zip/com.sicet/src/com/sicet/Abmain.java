package com.sicet;

public class Abmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          Ab b1=new Ab();
          b1.display();
	}

}
