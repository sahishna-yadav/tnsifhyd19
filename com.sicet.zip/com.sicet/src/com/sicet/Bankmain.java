package com.sicet;

public class Bankmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           Bank b1=new Sbi();
          System.out.println(b1.show());
          Bank c1=new Icic();
          System.out.println(c1.show());
          Bank d1=new Bankofbaroda();
          System.out.println(d1.show());
          
	}

}
