package com.sicet;

public interface Bank {
	int show();
}
	class Sbi implements Bank{
		public int show() {
			return 9;
		}
	}
	class Icic implements Bank{
		public int show() {
			return 10;
		}
	}
	class Bankofbaroda implements Bank{
		public int show() {
			return 15;
		}
	}



