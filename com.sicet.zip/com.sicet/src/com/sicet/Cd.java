package com.sicet;

public class Cd {
	public void show() {
		System.out.println("hi");
	}
	public static void main(String[] args) {
		Cd d1=new Cd();
		d1.show();
	}

}
