package com.sicet;

public class Ab {
	private void display() {
		System.out.println("hello");
	}
	public static void main(String[] args) {
		Ab a1=new Ab();
		a1.display();
	}

}
