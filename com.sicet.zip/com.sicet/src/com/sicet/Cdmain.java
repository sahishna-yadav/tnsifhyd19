package com.sicet;

public class Cdmain {

	public static void main(String[] args) {
		Cd c1=new Cd();
		c1.show();
		// TODO Auto-generated method stub

	}

}
