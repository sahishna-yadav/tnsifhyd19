package com.sicet;

public class Jackmain {

	public static void main(String[] args) {
		Jack j1=new Derived();
		j1.display();
		// TODO Auto-generated method stub

	}

}
