package com.sicet;

public interface Jack {
	public void display();
}
	class Derived implements Jack{
	public 	void display() {
			System.out.println("hello how are you");
			}
	}
		

