package com.cse;

public class Bat {
	static int a=10;
	int b=20;
	static void display() {
		System.out.println(A.a);
	}
	static int show() {
		System.out.println(b);
	}
	public static void main(String[] args) {
		A b1=new A();
		System.out.println(b1.b);
		display();
		show();
	}

}


