package com.cse;

 public class Parent {
	  void display() {
		System.out.println("father");
	}
}
class Child extends Parent {
	void display() {
		System.out.println("son");
			}
		}


