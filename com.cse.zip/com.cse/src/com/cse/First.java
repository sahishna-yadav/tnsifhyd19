package com.cse;

public class First {
	static void show() {
		System.out.println("hello");
	}
}
class Second extends First{
		static void show() {
			System.out.println("how are you");
		}
	}

