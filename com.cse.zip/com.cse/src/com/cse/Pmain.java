package com.cse;
public class Pmain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child c1=new Child();
		c1.display();
		}
}
