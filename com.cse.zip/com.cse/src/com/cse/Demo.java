package com.cse;

public class Demo {
	int a=10;
	static int b=20;
	int display() {
		System.out.println(a);
		return 30;
	}
	int show() {
		System.out.println(Demo.b);
		return 40;
	}
	public static void main(String[] args) {   
		Demo a1=new Demo();                      
		a1.display();
		a1.show();
		System.out.println(a1.display());  
		System.out.println(a1.show());
		
		
	}

}
