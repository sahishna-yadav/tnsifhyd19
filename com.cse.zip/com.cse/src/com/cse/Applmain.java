package com.cse;

public class Applmain {
	public static void main(String[] args) {
		Ball b1=new Ball();
		b1.cost();
		
	}

}
