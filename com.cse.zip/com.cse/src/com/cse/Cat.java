package com.cse;

public class Cat {
	static int plan() {
		System.out.println("hello");
		return 6;
	}
}
class Dog extends Cat{
	static int plan() {
		System.out.println("i love animals");
		return 5;
	}
	
}
