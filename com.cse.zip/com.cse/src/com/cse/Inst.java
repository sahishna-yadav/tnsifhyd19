package com.cse;

public class Inst {
	int a=10;
	static int b=20;
	void display() {
		System.out.println(a);
		}
	static void show() {
		System.out.println(Inst.b);
	}
	public static void main(String[] args) {
		Inst a1=new Inst();
		a1.display();
		Inst.show();
	}

}
