package com.cse;

public class Catmain{
	public static void main(String[] args) {
		
		System.out.println(Dog.plan());
	
		
	}
}
