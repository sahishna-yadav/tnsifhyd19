package com.cse;

public class A {
	static int a=10;
	int b=20;
	static void display() {
		System.out.println(A.a);
	}
	public static void main(String[] args) {
		A b1=new A();
		System.out.println(b1.b);
		display();
		
	}

}
