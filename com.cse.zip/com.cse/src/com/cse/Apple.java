package com.cse;

public class Apple {
	int cost() {
		System.out.println("ohh");
		return 10;
		}
}
	class Ball extends Apple{
		int cost() {
			System.out.println("i need apple");
			return 20;
		}
	}


