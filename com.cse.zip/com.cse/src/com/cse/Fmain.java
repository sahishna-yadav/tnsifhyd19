package com.cse;

public class Fmain {
	public static void main(String[] args) {
		Second.show();
	}

}
