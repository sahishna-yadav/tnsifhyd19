package net.codejava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RetriveData {
	
	public static void main(String[] args) {
		String dbURL = "jdbc:mysql://localhost:3306/employee";
		String username = "root";
		String password = "root";
		 
		try(Connection conn = DriverManager.getConnection(dbURL, username, password)) {
		 
			String sql = "SELECT * FROM empy";
			 
			Statement statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			 
			int count = 0;
			 
			while (result.next()){
			    String empid = result.getString(1);
			    String empname = result.getString("empname");
			    String empaddress = result.getString("empaddress");
			   
			 
			    String output = "User #%d: %s - %s - %s ";
			    System.out.println(String.format(output, ++count, empid, empname,empaddress));
			}
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}

	}

}
