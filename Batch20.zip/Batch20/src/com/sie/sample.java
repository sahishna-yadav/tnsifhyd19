package com.sie;

public class sample {
	int a=10;
	void cat()
	{  System.out.println("hi hello");
}
	
  static int b=20;
  static String camel()
  {
	  return "how are you";
  }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int c=30;
          sample S1=new sample();
          System.out.println(S1.a);
          S1.cat();
          System.out.println(sample.b);
          System.out.println(sample.camel());
          System.out.println(c);
          
	}

}
