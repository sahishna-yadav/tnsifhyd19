package com.sie;

public class Store {
	int a=100;
	static String b="sahishna";
	void biscuit() {
		System.out.println("hello!, can you provide me a biscuit");

	}
	static String cooldrink() {
		return "hello!,I need Thums up";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Store S1=new Store();
		System.out.println(S1.a);
		S1.biscuit();
		System.out.println(Store.b);
		System.out.println(Store.cooldrink());
		int c=40;
		System.out.println(c);
		
		

	}

}
