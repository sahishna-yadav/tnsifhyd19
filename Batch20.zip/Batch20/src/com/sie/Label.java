package com.sie;

public class Label {
	

	public static void main(String[] args) {
		Normal N1= new Normal();
		System.out.println(N1.a);
		N1.star();
		System.out.println(Normal.b);
		System.out.println(Normal.moon());
		int c=10;
		System.out.println(c);
		
		// TODO Auto-generated method stub

	}

}
