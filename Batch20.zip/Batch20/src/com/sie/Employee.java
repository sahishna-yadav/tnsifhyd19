package com.sie;

public class Employee {
	int empid=1;
	static  String empname="sahishna";
	public static void main(String args[])
	{
		 int employee_salary=40000;
		System.out.println(employee_salary);
		Employee E1=new Employee();
		System.out.println(E1.empid);
		System.out.println(Employee.empname);
		
		
	}
	

}
