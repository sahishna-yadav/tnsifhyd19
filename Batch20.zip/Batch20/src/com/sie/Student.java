package com.sie;

public class Student {
	int a=10;
	static int b=30;

	public static void main(String[] args) {
		int c=40;
		System.out.println(c);
		Student S1=new Student();
		System.out.println(S1.a);
		System.out.println(Student.b);
		
		
		// TODintO Auto-generated method stub

	}

}
