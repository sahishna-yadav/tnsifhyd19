package com.sie;

public class Normal {
	int a=20;
	void star() {
		System.out.println("hi hello");
	}
	static int b=80;
	static String moon() {
		return "what are you doing so";
	}

}
