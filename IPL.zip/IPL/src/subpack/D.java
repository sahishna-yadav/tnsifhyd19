package subpack;

public class D {
	public void msg() {
		System.out.println("hello");
	}

}
