package packs;

public class A {
public void msg() {
	System.out.println("2HELLO");
}
}
