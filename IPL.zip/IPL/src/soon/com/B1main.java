package soon.com;

public class B1main {
	public static void main(String[] args) {
		Bike1 b2=new Bike1();
		b2.setModel("Duke");
		System.out.println(b2.getModel());
		b2.setEngine("on");
		System.out.println(b2.getEngine());
		b2.setLight("glow");
		System.out.println(b2.getLight());
		b2.setSpeed(20);
		System.out.println(b2.getSpeed());
		
	}

}
