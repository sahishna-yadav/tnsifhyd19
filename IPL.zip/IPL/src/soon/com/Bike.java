package soon.com;

public class Bike {
	private String model;
	private String engine;
	private String light;
	public int speed;

}
