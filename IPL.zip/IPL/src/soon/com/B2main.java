package soon.com;

public class B2main {
	public static void main(String[] args) {
		Bike2 b3=new Bike2();
		b3.setModel("duku");
		b3.setEngine("on");
		b3.setLight("glow");
		b3.setSpeed(-10);
		System.out.println(b3.msg());
	}

}
