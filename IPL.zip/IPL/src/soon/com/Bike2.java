package soon.com;

public class Bike2 {
	private String model;
	private String engine;
	private String light;
	private int speed;
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getEngine() {
		return engine;
	}
	public void setEngine(String engine) {
		this.engine = engine;
	}
	public String getLight() {
		return light;
	}
	public void setLight(String light) {
		this.light = light;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public String msg() {
		if(model.equals("duku")  && engine.equals("on") && light.equals("glow") && speed>0) {
			return "GOOD BIKE";
		}
			else {
				return "NOT GOOD BIKE";
				
			}
			
		}
	}
	    
	


