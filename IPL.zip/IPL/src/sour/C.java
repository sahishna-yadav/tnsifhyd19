package sour;
	import packs.*;
	import subpack.*;
	public class C {
		public static void main(String args[]) {
			A obj=new A();
			D obj1=new D();
			obj.msg();
			obj1.msg();
			
		}

	}



