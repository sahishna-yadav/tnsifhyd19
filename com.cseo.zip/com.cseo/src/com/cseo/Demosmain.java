package com.cseo;

public class Demosmain {

	public static void main(String[] args) {
		Dare d1=new Dare();
		d1.show();
		// TODO Auto-generated method stub

	}

}
