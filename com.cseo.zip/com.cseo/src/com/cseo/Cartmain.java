package com.cseo;

public class Cartmain {

	public static void main(String[] args) {
		Sweet s1=new Sweet();
		  s1.display();
		// TODO Auto-generated method stub

	}

}
