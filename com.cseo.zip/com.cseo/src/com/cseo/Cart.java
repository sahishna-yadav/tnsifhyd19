package com.cseo;

final class Cart {
	void display() {
		System.out.println("hey is this mine");
		}
	}
class Sweet extends Cart{
	void display() {
		System.out.println("what are you doing so");
	}
}
