package com.cseo;

public class Hierinheritance {
	void eat() {
		System.out.println("eating");
 }

}
class Dog extends Hierinheritance{
	void bark() {
		System.out.println("barking");
	}
}
class Stor extends Hierinheritance{
	void shop() {
		System.out.println("shopping");
	}
}
