package com.cseo;

public class Animals {
  final	 int typeofanimals=100;
	  void run() {
		  typeofanimals=40;
		  System.out.println("hello");
		 
	  }

	public static void main(String[] args) {
		Animals a1=new Animals();
       a1.run();
       System.out.println(a1.typeofanimals);
		
		// TODO Auto-generated method stub

	

}
}
