package com.cseo;

public class Consparametermain {
	public static void main(String[] args) {

	Constparameter c1=new Constparameter("pakkahouse","on","bmw",10);
	System.out.println(c1.run());
	

}
}
