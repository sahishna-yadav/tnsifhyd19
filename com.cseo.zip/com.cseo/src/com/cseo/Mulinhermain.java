package com.cseo;

public class Mulinhermain {

	public static void main(String[] args) {
		Stop s1=new Stop();
		s1.eat();
		s1.bark();
		s1.shop();
		// TODO Auto-generated method stub

	}

}
