package com.cseo;

public class Polymer {
	int display(byte x,int y) {
		return 10;
	}
	int display(int y,short z) {
		return 20;
		}
	int display(byte x,int y,short z) {
		return 30;
	}
	
}

