package com.cseo;

public class Demos {
 final	void show() {
 		System.out.println("how are you");
		
	}

}
class Dare extends Demos{
	void show() {
		System.out.println("what is going on");
	}
	
}
