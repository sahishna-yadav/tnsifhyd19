package com.cseo;

public class mulinheritance {
	void eat() {
		System.out.println("eating");
	}
	}
class Store extends mulinheritance{
	void bark() {
		System.out.println("barking");
	}
	}
class Stop extends Store{
	void shop() {
		System.out.println("shopping");
	}
}