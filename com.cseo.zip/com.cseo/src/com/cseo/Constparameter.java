package com.cseo;

public class Constparameter {
	private String house;
	private String light;
	private String car;
	private int door;
	public Constparameter(String house,String light,String car,int door) {
		this.house=house;
		this.light=light;
		this.car=car;
		this.door=door;
		
	}
	public String run() {
		if(house.equals("pakkahouse")&& light.equals("on")&&car.equals("bmw")&&door>5) {
			return " I have a beautiful HOUSE";
			}
		else {
			return "I dont have own house";
		}
	}

}
