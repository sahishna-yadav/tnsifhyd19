package com.cseo;

public class Polymetmain {

	public static void main(String[] args) {
	 byte a=1;
	 int b=10;
	 short c=2;
	  int result;
	  Polymer p1=new Polymer();
	  result=p1.display(a,b);
	  System.out.println("addition" +result);
	  result=p1.display(b,c);
	  System.out.println("addition"+result);
	  result=p1.display(a,b,c);
	  System.out.println("addition" +result);
	  
	  
	  
	 
		// TODO Auto-generated method stub

	}

}
