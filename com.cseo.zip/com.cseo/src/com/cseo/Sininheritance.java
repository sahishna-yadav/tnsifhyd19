package com.cseo;

public class Sininheritance {
	void eat() {
		System.out.println("I m eating");
	}
}
	class Shop extends Sininheritance{
		void bark() {
			System.out.println("barking");
		}
		
	}


