package com.cseo;

public class Constructor {
	private String model;
	private String engine;
	private String light;
	private int speed;
public Constructor(){
	model="duke";
	engine="on";
	light="glow";
	speed=10;
}
public int show(){
	if(model.equals("duke") && engine.equals("off")&& light.equals("glow")&& speed>0) {
		return 10;
		}
	else {
		return 20;
	}
	}
}
