package com.cseo;

public class Sininherimain {

	public static void main(String[] args) {
		Shop s1=new Shop();
		s1.eat();
		s1.bark();
		// TODO Auto-generated method stub

	}

}
