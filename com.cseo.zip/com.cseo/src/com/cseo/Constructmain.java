package com.cseo;

public class Constructmain {
	public static void main(String[] args) {
		Constructor c1=new Constructor();
		System.out.println(c1.show());
	}

}
